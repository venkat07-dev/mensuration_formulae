# mensuration_formulae :
A PyPI package that can be used to find the values of area,perimeter,volume,surface area of 2d & 3d geometric shapes.

# Installation :
Run the following to install:

'''cmd
pip install mensuration-formulae
'''

# Team :
## Contributor : Venkateswar.S
## Mentor      : Maria Irudaya Regilan J